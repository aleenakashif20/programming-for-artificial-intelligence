from flask import Flask, render_template, request, jsonify
from transformers import pipeline
import nltk
from nltk.tokenize import sent_tokenize
import torch

# Download NLTK data
nltk.download('punkt')

app = Flask(__name__)

# Initialize summarization pipeline (using BART model)
# Falls back to CPU if CUDA not available
device = 0 if torch.cuda.is_available() else -1

try:
    summarizer = pipeline(
        "summarization",
        model="facebook/bart-large-cnn",
        device=device
    )
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")
    # Fallback to a smaller model
    summarizer = pipeline(
        "summarization",
        model="sshleifer/distilbart-cnn-12-6",
        device=device
    )

def chunk_text(text, max_chunk_size=1024):
    """Split long text into smaller chunks"""
    sentences = sent_tokenize(text)
    chunks = []
    current_chunk = []
    current_length = 0
    
    for sentence in sentences:
        sentence_length = len(sentence.split())
        if current_length + sentence_length > max_chunk_size:
            chunks.append(' '.join(current_chunk))
            current_chunk = [sentence]
            current_length = sentence_length
        else:
            current_chunk.append(sentence)
            current_length += sentence_length
    
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    
    return chunks

def summarize_text(text, max_length=150, min_length=50):
    """Generate summary for given text"""
    if not text or len(text.strip()) < 50:
        return "Text is too short to summarize. Please enter at least 50 characters."
    
    # Check if text is too long (more than 1024 tokens)
    chunks = chunk_text(text)
    
    summaries = []
    for chunk in chunks:
        if len(chunk.split()) < 30:
            summaries.append(chunk)
        else:
            try:
                summary = summarizer(
                    chunk,
                    max_length=max_length,
                    min_length=min_length,
                    do_sample=False
                )
                summaries.append(summary[0]['summary_text'])
            except Exception as e:
                print(f"Error summarizing chunk: {e}")
                summaries.append(chunk[:500])
    
    # Combine chunk summaries
    final_summary = ' '.join(summaries)
    
    # If still too long, summarize again
    if len(final_summary.split()) > 300:
        try:
            final_summary = summarizer(
                final_summary,
                max_length=max_length,
                min_length=min_length,
                do_sample=False
            )[0]['summary_text']
        except:
            pass
    
    return final_summary

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/summarize', methods=['POST'])
def summarize():
    try:
        data = request.get_json()
        text = data.get('text', '')
        max_length = int(data.get('max_length', 150))
        min_length = int(data.get('min_length', 50))
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        # Generate summary
        summary = summarize_text(text, max_length, min_length)
        
        # Calculate statistics
        original_word_count = len(text.split())
        summary_word_count = len(summary.split())
        compression_ratio = round((1 - summary_word_count/original_word_count) * 100, 2) if original_word_count > 0 else 0
        
        return jsonify({
            'summary': summary,
            'original_length': original_word_count,
            'summary_length': summary_word_count,
            'compression_ratio': compression_ratio
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)